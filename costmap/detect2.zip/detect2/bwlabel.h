//
// File: bwlabel.h
//
// MATLAB Coder version            : 5.3
// C/C++ source code generated on  : 03-Apr-2022 14:20:30
//

#ifndef BWLABEL_H
#define BWLABEL_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void bwlabel(const bool varargin_1[32000], double L[32000],
             double *numComponents);

}

#endif
//
// File trailer for bwlabel.h
//
// [EOF]
//
