//
// File: adaptthresh.h
//
// MATLAB Coder version            : 5.3
// C/C++ source code generated on  : 03-Apr-2022 14:20:30
//

#ifndef ADAPTTHRESH_H
#define ADAPTTHRESH_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void localMeanThresh(const double b_I[32000], double T[32000]);

}

#endif
//
// File trailer for adaptthresh.h
//
// [EOF]
//
