//
// File: detect2_terminate.cpp
//
// MATLAB Coder version            : 5.3
// C/C++ source code generated on  : 03-Apr-2022 14:20:30
//

// Include Files
#include "detect2_terminate.h"

// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
void detect2_terminate()
{
  // (no terminate code required)
}

//
// File trailer for detect2_terminate.cpp
//
// [EOF]
//
