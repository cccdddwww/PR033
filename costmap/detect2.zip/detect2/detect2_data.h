//
// File: detect2_data.h
//
// MATLAB Coder version            : 5.3
// C/C++ source code generated on  : 03-Apr-2022 14:20:30
//

#ifndef DETECT2_DATA_H
#define DETECT2_DATA_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

#endif
//
// File trailer for detect2_data.h
//
// [EOF]
//
