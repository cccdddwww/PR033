//
// File: inPainting.h
//
// MATLAB Coder version            : 5.3
// C/C++ source code generated on  : 03-Apr-2022 14:20:30
//

#ifndef INPAINTING_H
#define INPAINTING_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void inPainting(const unsigned char b_I[32000], const bool mask[32000],
                unsigned char R[32000]);

#endif
//
// File trailer for inPainting.h
//
// [EOF]
//
