//
// File: detect2_terminate.h
//
// MATLAB Coder version            : 5.3
// C/C++ source code generated on  : 03-Apr-2022 14:20:30
//

#ifndef DETECT2_TERMINATE_H
#define DETECT2_TERMINATE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void detect2_terminate();

#endif
//
// File trailer for detect2_terminate.h
//
// [EOF]
//
