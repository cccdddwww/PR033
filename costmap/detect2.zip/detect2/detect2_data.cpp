//
// File: detect2_data.cpp
//
// MATLAB Coder version            : 5.3
// C/C++ source code generated on  : 03-Apr-2022 14:20:30
//

// Include Files
#include "detect2_data.h"

//
// File trailer for detect2_data.cpp
//
// [EOF]
//
