//
// File: imbinarize.h
//
// MATLAB Coder version            : 5.3
// C/C++ source code generated on  : 03-Apr-2022 14:20:30
//

#ifndef IMBINARIZE_H
#define IMBINARIZE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void imbinarize(const unsigned char b_I[32000], bool BW[32000]);

}

#endif
//
// File trailer for imbinarize.h
//
// [EOF]
//
