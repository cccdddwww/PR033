//
// File: detect2.h
//
// MATLAB Coder version            : 5.3
// C/C++ source code generated on  : 03-Apr-2022 14:20:30
//

#ifndef DETECT2_H
#define DETECT2_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void detect2(const unsigned char img[32000],
                    coder::array<double, 2U> &Result, double *t);

#endif
//
// File trailer for detect2.h
//
// [EOF]
//
