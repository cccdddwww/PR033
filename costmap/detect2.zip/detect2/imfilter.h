//
// File: imfilter.h
//
// MATLAB Coder version            : 5.3
// C/C++ source code generated on  : 03-Apr-2022 14:20:30
//

#ifndef IMFILTER_H
#define IMFILTER_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
void imfilter(const unsigned char varargin_1[32000], unsigned char b[32000]);

}

#endif
//
// File trailer for imfilter.h
//
// [EOF]
//
