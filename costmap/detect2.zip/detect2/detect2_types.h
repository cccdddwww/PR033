//
// File: detect2_types.h
//
// MATLAB Coder version            : 5.3
// C/C++ source code generated on  : 03-Apr-2022 14:20:30
//

#ifndef DETECT2_TYPES_H
#define DETECT2_TYPES_H

// Include Files
#include "rtwtypes.h"

#endif
//
// File trailer for detect2_types.h
//
// [EOF]
//
