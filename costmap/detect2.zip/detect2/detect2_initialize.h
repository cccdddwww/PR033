//
// File: detect2_initialize.h
//
// MATLAB Coder version            : 5.3
// C/C++ source code generated on  : 03-Apr-2022 14:20:30
//

#ifndef DETECT2_INITIALIZE_H
#define DETECT2_INITIALIZE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void detect2_initialize();

#endif
//
// File trailer for detect2_initialize.h
//
// [EOF]
//
