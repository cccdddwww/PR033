//
// File: _coder_detect2_info.h
//
// MATLAB Coder version            : 5.3
// C/C++ source code generated on  : 03-Apr-2022 14:20:30
//

#ifndef _CODER_DETECT2_INFO_H
#define _CODER_DETECT2_INFO_H

// Include Files
#include "mex.h"

// Function Declarations
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties();

#endif
//
// File trailer for _coder_detect2_info.h
//
// [EOF]
//
