//
// File: _coder_detect2_info.cpp
//
// MATLAB Coder version            : 5.3
// C/C++ source code generated on  : 03-Apr-2022 14:20:30
//

// Include Files
#include "_coder_detect2_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

// Function Declarations
static const mxArray *emlrtMexFcnResolvedFunctionsInfo();

// Function Definitions
//
// Arguments    : void
// Return Type  : const mxArray *
//
static const mxArray *emlrtMexFcnResolvedFunctionsInfo()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[5]{
      "789cdd55cb4ec240141d148cf181acfc0cd3b42c84c44482851444311013634d2c748062"
      "3b43da29818f307e822cddb9f53b8c0b7fc27f105a4a9926132025f5"
      "7137b727e74ecfe9bded2d88499518002009dc78db75f3fe14a7a67903d011e46381ba18"
      "5d0e12204e9df3f8a7696e6244e080b80029069c9d54b1a1210591fa",
      "b00781092dacf7a1ea302d4d8775cd80b57970314146618e9a810935b9ce7760f3a1661b"
      "c0ec58be437d1eccfa31623c6f7cc97e6419fd4805f85bf14eccca55"
      "1377619358724521bad2902584705f21b0502de664cd50da90e7789e13f88cac4232aee4"
      "8f0cda6f2fa4df9d057e3d5e4355454344436d5aff3ea47e82a9ef32",
      "f658f418ac6f3e274c3d9a5f793e7e839c112deacfc1927e83d9afdf76f287f8e95051e9"
      "95f61e4fa3d4f3e2a7f4068cfb2dfbbe1d32f45201bea00a57989c95"
      "5bb03b14ba96c609372558f47d5417e82cf2011838aafb8f18e77feb771b76af260338e8"
      "d7e3a589993ace63dd3690b5bebdbac5d4771915db0d1dfa7a2f21f5",
      "724c3d9a5f793e7483bcdf5f64fbe03de2fdfab5f9fa1ca59e17ff7dbf664c542873b67e"
      "96eee4ecf35a3a2d0dae2fc5bfbf5fbf018d11b3e5",
      ""};
  nameCaptureInfo = nullptr;
  emlrtNameCaptureMxArrayR2016a(&data[0], 3024U, &nameCaptureInfo);
  return nameCaptureInfo;
}

//
// Arguments    : void
// Return Type  : mxArray *
//
mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[6]{
      "Name",           "NumberOfInputs", "NumberOfOutputs",
      "ConstantInputs", "FullPath",       "TimeStamp"};
  const char_T *propFieldName[5]{"Version", "ResolvedFunctions", "EntryPoints",
                                 "CoverageInfo", "IsPolymorphic"};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 1, 6, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 0, (const char_T *)"Name",
                emlrtMxCreateString((const char_T *)"detect2"));
  emlrtSetField(xEntryPoints, 0, (const char_T *)"NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, (const char_T *)"NumberOfOutputs",
                emlrtMxCreateDoubleScalar(2.0));
  emlrtSetField(xEntryPoints, 0, (const char_T *)"ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, (const char_T *)"FullPath",
      emlrtMxCreateString(
          (const char_T
               *)"E:\\Projects\\Matlab\\InnovateFPGA\\image20220329\\detect2."
                 "m"));
  emlrtSetField(xEntryPoints, 0, (const char_T *)"TimeStamp",
                emlrtMxCreateDoubleScalar(738614.59672453708));
  xResult =
      emlrtCreateStructMatrix(1, 1, 5, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, (const char_T *)"Version",
                emlrtMxCreateString((const char_T *)"9.11.0.1769968 (R2021b)"));
  emlrtSetField(xResult, 0, (const char_T *)"ResolvedFunctions",
                (mxArray *)emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, (const char_T *)"EntryPoints", xEntryPoints);
  return xResult;
}

//
// File trailer for _coder_detect2_info.cpp
//
// [EOF]
//
