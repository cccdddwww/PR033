//
// File: _coder_detect2_api.h
//
// MATLAB Coder version            : 5.3
// C/C++ source code generated on  : 03-Apr-2022 14:20:30
//

#ifndef _CODER_DETECT2_API_H
#define _CODER_DETECT2_API_H

// Include Files
#include "coder_array_mex.h"
#include "emlrt.h"
#include "tmwtypes.h"
#include <algorithm>
#include <cstring>

// Variable Declarations
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

// Function Declarations
void detect2(uint8_T img[32000], coder::array<real_T, 2U> *Result, real_T *t);

void detect2_api(const mxArray *prhs, int32_T nlhs, const mxArray *plhs[2]);

void detect2_atexit();

void detect2_initialize();

void detect2_terminate();

void detect2_xil_shutdown();

void detect2_xil_terminate();

#endif
//
// File trailer for _coder_detect2_api.h
//
// [EOF]
//
