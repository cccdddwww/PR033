//
// File: useConstantDim.h
//
// MATLAB Coder version            : 5.3
// C/C++ source code generated on  : 03-Apr-2022 14:20:30
//

#ifndef USECONSTANTDIM_H
#define USECONSTANTDIM_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
void useConstantDim(double varargin_2[40320], int varargin_3);

}
} // namespace coder

#endif
//
// File trailer for useConstantDim.h
//
// [EOF]
//
